# LinkGuard Python 재구성본

원본과 동일한 복구본이 아닙니다. `server/`에서 실행하며 [서버 안내](server/README.md)를 참고하세요. Python3.11 이상이 필요합니다. 실제 학습 데이터와 학습 모델은 포함하지 않습니다.
